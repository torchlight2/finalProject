scotchApp.controller("FantasyController", ['$scope','$http', 
	function($scope, $http)
		{    
			$http.get('app/directives/fantasy.json').success(function(data){
				$scope.fantasy = data.record;
			}); 
		}]
);

scotchApp.controller("fantasyView", ['$scope','$http','$routeParams',
	 function($scope, $http, $routeParams)
		{    
			$http.get('app/directives/fantasy.json').success (function(data){
				$scope.fantasy = data.record;
				$scope.whichBook = $routeParams.fantasyID;
			}); 
		}]
);
