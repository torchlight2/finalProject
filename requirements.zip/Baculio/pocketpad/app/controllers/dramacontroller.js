		scotchApp.controller("DramaController", ['$scope','$http', function($scope, $http)
		{    
			$http.get('app/directives/drama.json').success(function(data){
				$scope.drama = data.record;
			}); 
		}]
);

scotchApp.controller("dramaView", ['$scope','$http','$routeParams',function($scope, $http, $routeParams)
		{    
			$http.get('app/directives/drama.json').success (function(data){
				$scope.drama = data.record;
				$scope.whichBook = $routeParams.dramaID;
			}); 
		}]
);
