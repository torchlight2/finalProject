scotchApp.controller("HorrorController", ['$scope','$http', 
	function($scope, $http)
		{    
			$http.get('app/directives/horror.json').success(function(data){
				$scope.horror = data.record;
			}); 
		}]
);
		scotchApp.controller("horrorView", ['$scope','$http','$routeParams',
	 function($scope, $http, $routeParams)
		{    
			$http.get('app/directives/horror.json').success (function(data){
				$scope.horror = data.record;
				$scope.whichBook = $routeParams.horrorID;
			}); 
		}]
);