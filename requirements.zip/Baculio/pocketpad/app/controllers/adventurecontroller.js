		scotchApp.controller("AdventureController", ['$scope','$http', 
	function($scope, $http)
		{    
			$http.get('app/directives/adventure.json').success(function(data){
				$scope.adventure = data.record;
			}); 
		}]
);

		scotchApp.controller("adventureView", ['$scope','$http','$routeParams',
	 function($scope, $http, $routeParams)
		{    
			$http.get('app/directives/adventure.json').success (function(data){
				$scope.adventure = data.record;
				$scope.whichBook = $routeParams.adventureID;
			}); 
		}]
);