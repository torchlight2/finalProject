scotchApp.controller("ActionController", ['$scope','$http', 
	function($scope, $http)
		{    
			$http.get('app/directives/action.json').success(function(data){
				$scope.action = data.record;
			}); 
		}]
);

scotchApp.controller("ViewController", ['$scope','$http','$routeParams',
	 function($scope, $http, $routeParams)
		{    
			$http.get('app/directives/action.json').success (function(data){
				$scope.action = data.record;
				$scope.whichBook = $routeParams.actionID;
			}); 
		}]
);
