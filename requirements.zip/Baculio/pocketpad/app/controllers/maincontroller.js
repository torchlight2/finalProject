angular
	.module('scotchApp')
	.controller('MainController',function($scope){
            $scope.pageTitle = 'Main Controller with View';
        });