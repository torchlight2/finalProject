scotchApp.controller("RomanceController", ['$scope','$http', 
	function($scope, $http)
		{    
			$http.get('app/directives/romance.json').success(function(data){
				$scope.romance = data.record;
			}); 
		}]
);
		scotchApp.controller("romanceView", ['$scope','$http','$routeParams',
	 function($scope, $http, $routeParams)
		{    
			$http.get('app/directives/romance.json').success (function(data){
				$scope.romance = data.record;
				$scope.whichBook = $routeParams.romanceID;
			}); 
		}]
);