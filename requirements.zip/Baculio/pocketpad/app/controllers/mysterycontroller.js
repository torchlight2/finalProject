scotchApp.controller("MysteryController", ['$scope','$http', 
	function($scope, $http)
		{    
			$http.get('app/directives/mystery.json').success(function(data){
				$scope.mystery = data.record;
			}); 
		}]
);

		scotchApp.controller("mysteryView", ['$scope','$http','$routeParams',
	 function($scope, $http, $routeParams)
		{    
			$http.get('app/directives/mystery.json').success (function(data){
				$scope.mystery = data.record;
				$scope.whichBook = $routeParams.mysteryID;
			}); 
		}]
);