var scotchApp = angular.module('scotchApp', ['ngRoute']);
 
    scotchApp.config(function($routeProvider){
        $routeProvider
        	
			.when('/home',{
				 templateUrl: 'app/partials/home.html',
				 controller: 'MainController'
			})

			.when('/action/read/:actionID',{
				 templateUrl: 'app/partials/action/view.html',
				 controller: 'ViewController'
			})

			.when('/adventure/read/:adventureID',{
				 templateUrl: 'app/partials/adventure/view.html',
				 controller: 'adventureView'
			})

			.when('/drama/read/:dramaID',{
				 templateUrl: 'app/partials/drama/view.html',
				 controller: 'dramaView'
			})

			.when('/fantasy/read/:fantasyID',{
				 templateUrl: 'app/partials/fantasy/view.html',
				 controller: 'fantasyView'
			})

			.when('/horror/read/:horrorID',{
				 templateUrl: 'app/partials/horror/view.html',
				 controller: 'horrorView'
			})

			.when('/mystery/read/:mysteryID',{
				 templateUrl: 'app/partials/mystery/view.html',
				 controller: 'mysteryView'
			})

			.when('/romance/read/:romanceID',{
				 templateUrl: 'app/partials/romance/view.html',
				 controller: 'romanceView'
			})
			
			.when ('/discover',{
				templateUrl: 'app/partials/discover.html',
				controller : 'DiscoverController'
			})

			.when ('/action',{
				 templateUrl: 'app/partials/action/action.html',
				 controller : 'ActionController'
			})

			.when ('/adventure',{
				templateUrl: 'app/partials/adventure/adventure.html',
				controller : 'AdventureController'
			})

			.when ('/drama',{
				 templateUrl: 'app/partials/drama/drama.html',
				 controller : 'DramaController'
			})
			.when ('/fantasy',{
				templateUrl: 'app/partials/fantasy/fantasy.html',
				controller : 'FantasyController'
			})

			.when ('/horror',{
				templateUrl: 'app/partials/horror/horror.html',
				controller : 'HorrorController'
			})

			.when ('/mystery',{
				templateUrl: 'app/partials/mystery/mystery.html',
				controller : 'MysteryController'
			})

			.when ('/romance',{
				 templateUrl: 'app/partials/romance/romance.html',
				 controller : 'RomanceController'
			})

			.when ('/davinci',{
				 templateUrl: 'app/partials/davinci.html',
				 controller : 'DavinciController'
			})
			.when ('/hungerGames',{
				 templateUrl: 'app/partials/hungerGames.html',
				 controller : 'HungerGamesController'
			})
			.when ('/catchingFire',{
				 templateUrl: 'app/partials/catchingFire.html',
				 controller : 'CatchingFireController'
			})
			.when ('/mockingjay',{
				 templateUrl: 'app/partials/mockingjay.html',
				 controller : 'MockingjayController'
			})
			.when ('/divergent',{
				 templateUrl: 'app/partials/divergent.html',
				 controller : 'DivergentController'
			})
			.when ('/insurgent',{
				 templateUrl: 'app/partials/insurgent.html',
				 controller : 'InsurgentController'
			})
			.when ('/mazerunner',{
				 templateUrl: 'app/partials/mazerunner.html',
				 controller : 'MazerunnerController'
			})
			.when ('/maze',{
				 templateUrl: 'app/partials/maze.html',
				 controller : 'MazeController'
			})
			.when ('/cityofbones',{
				 templateUrl: 'app/partials/cityofbones.html',
				 controller : 'CityofbonesController'
			})
			.when ('/angelanddemons',{
				 templateUrl: 'app/partials/angelanddemons.html',
				 controller : 'AngelanddemonsController'
			})
			.when ('/huckleberry',{
				 templateUrl: 'app/partials/huckleberry.html',
				 controller : 'HuckleberryController'
			})

			.when ('/kavalierclay',{
				 templateUrl: 'app/partials/kavalierclay.html',
				 controller : 'KavalierclayController'
			})
			.when ('/sherlockholmes',{
				 templateUrl: 'app/partials/sherlockholmes.html',
				 controller : 'SherlockholmesController'
			})
			.when ('/ishmael',{
				 templateUrl: 'app/partials/ishmael.html',
				 controller : 'IshmaelController'
			})
			.when ('/whatthedogsaw',{
				 templateUrl: 'app/partials/whatthedogsaw.html',
				 controller : 'WhatthedogsawController'
			})
			.when ('/robinhood',{
				 templateUrl: 'app/partials/robinhood.html',
				 controller : 'RobinhoodController'
			})
			.when ('/augie',{
				 templateUrl: 'app/partials/augie.html',
				 controller : 'AugieController'
			})

			.when ('/gulp',{
				 templateUrl: 'app/partials/gulp.html',
				 controller : 'GulpController'
			})
			.when ('/faultinourstar',{
				 templateUrl: 'app/partials/faultinourstar.html',
				 controller : 'FaultinourstarController'
			})
			.when ('/ifistay',{
				 templateUrl: 'app/partials/ifistay.html',
				 controller : 'IfistayController'
			})
			.when ('/waterforelephants',{
				 templateUrl: 'app/partials/waterforelephants.html',
				 controller : 'WaterforelephantsController'
			})
			.when ('/lovelybones',{
				 templateUrl: 'app/partials/lovelybones.html',
				 controller : 'LovelybonesController'
			})
			.when ('/romeo&juliet',{
				 templateUrl: 'app/partials/romeo&juliet.html',
				 controller : 'Romeo&julietController'
			})
			.when ('/WutheringHeights',{
				 templateUrl: 'app/partials/WutheringHeights.html',
				 controller : 'WutheringHeightsController'
			})
			.when ('/lookingforAlaska',{
				 templateUrl: 'app/partials/lookingforAlaska.html',
				 controller : 'LookingforAlaskaController'
			})
			.when ('/thirteenReasonsWhy',{
				 templateUrl: 'app/partials/thirteenReasonsWhy.html',
				 controller : 'ThirteenReasonsWhyController'
			})
			.when ('/thehelp',{
				 templateUrl: 'app/partials/thehelp.html',
				 controller : 'thehelpController'
			})
			.when ('/twilight',{
				 templateUrl: 'app/partials/twilight.html',
				 controller : 'TwilightController'
			})
			.when ('/dracula',{
				 templateUrl: 'app/partials/dracula.html',
				 controller : 'DraculaController'
			})
			.when ('/theHobbit',{
				 templateUrl: 'app/partials/theHobbit.html',
				 controller : 'TheHobbitController'
			})

			.when ('/gulp',{
				 templateUrl: 'app/partials/gulp.html',
				 controller : 'GulpController'
			})
			.when ('/theFellowshipoftheRing',{
				 templateUrl: 'app/partials/theFellowshipoftheRing.html',
				 controller : 'TheFellowshipoftheRingController'
			})
			.when ('/harryPotterandtheSorcerersStone',{
				 templateUrl: 'app/partials/harryPotterandtheSorcerersStone.html',
				 controller : 'HarryPotterandtheSorcerersStoneController'
			})
			.when ('/theLiontheWitchandtheWardrobe',{
				 templateUrl: 'app/partials/theLiontheWitchandtheWardrobe.html',
				 controller : 'TheLiontheWitchandtheWardrobeController'
			})
			.when ('/aGameofThrones',{
				 templateUrl: 'app/partials/aGameofThrones.html',
				 controller : 'AGameofThronesController'
			})
			.when ('/theGiver',{
				 templateUrl: 'app/partials/theGiver.html',
				 controller : 'TheGiverController'
			})
			.when ('/newMoon',{
				 templateUrl: 'app/partials/newMoon.html',
				 controller : 'NewMoonController'
			})
			.when ('/eclipse',{
				 templateUrl: 'app/partials/eclipse.html',
				 controller : 'EclipseController'
			})
			.when ('/dracula',{
				 templateUrl: 'app/partials/dracula.html',
				 controller : 'DraculaController'
			})

			.when ('/thePictureofDorianGray',{
				 templateUrl: 'app/partials/thePictureofDorianGray.html',
				 controller : 'ThePictureofDorianGrayController'
			})
			.when ('/frankenstein',{
				 templateUrl: 'app/partials/frankenstein.html',
				 controller : 'FrankensteinController'
			})
			.when ('/theShining',{
				 templateUrl: 'app/partials/theShining.html',
				 controller : 'TheShiningController'
			})

			.when ('/TheRoad',{
				 templateUrl: 'app/partials/theRoad.html',
				 controller : 'TheRoadController'
			})
			.when ('/AClockworkOrange',{
				 templateUrl: 'app/partials/aClockworkOrange.html',
				 controller : 'AClockworkOrangeController'
			})
			.when ('/jurassicPark',{
				 templateUrl: 'app/partials/jurassicPark.html',
				 controller : 'JurassicParkController'
			})
			.when ('/beautifulCreatures',{
				 templateUrl: 'app/partials/beautifulCreatures.html',
				 controller : 'BeautifulCreaturesController'
			})

			.when ('/theGirlwiththeDragonTattoo',{
				 templateUrl: 'app/partials/theGirlwiththeDragonTattoo.html',
				 controller : 'TheGirlwiththeDragonTattooController'
			})
			.when ('/vampireAcademy',{
				 templateUrl: 'app/partials/vampireAcademy.html',
				 controller : 'VampireAcademyController'
			})
			.when ('/goneGirl',{
				 templateUrl: 'app/partials/goneGirl.html',
				 controller : 'GoneGirlController'
			})
			.when ('/paperTowns',{
				 templateUrl: 'app/partials/paperTowns.html',
				 controller : 'PaperTownsController'
			})

			.when ('/deceptionPoint',{
				 templateUrl: 'app/partials/deceptionPoint.html',
				 controller : 'DeceptionPointController'
			})
			.when ('/theFirm',{
				 templateUrl: 'app/partials/theFirm.html',
				 controller : 'TheFirmController'
			})
			.when ('/aTimetoKill',{
				 templateUrl: 'app/partials/aTimetoKill.html',
				 controller : 'ATimetoKillController'
			})
			.when ('/holes',{
				 templateUrl: 'app/partials/holes.html',
				 controller : 'HolesController'
			})
			.when ('/theLostSymbol',{
				 templateUrl: 'app/partials/theLostSymbol.html',
				 controller : 'TheLostSymbolController'
			})
			.when ('/andThenThereWereNone',{
				 templateUrl: 'app/partials/andThenThereWereNone.html',
				 controller : 'AndThenThereWereNoneController'
			})

			.when ('/prideandPrejudice',{
				 templateUrl: 'app/partials/prideandPrejudice.html',
				 controller : 'PrideandPrejudiceController'
			})
			.when ('/theTimeTravelersWife',{
				 templateUrl: 'app/partials/theTimeTravelersWife.html',
				 controller : 'TheTimeTravelersWifeController'
			})
			.when ('/janeEyre',{
				 templateUrl: 'app/partials/janeEyre.html',
				 controller : 'JaneEyreController'
			})
			.when ('/theNotebook',{
				 templateUrl: 'app/partials/theNotebook.html',
				 controller : 'TheNotebookController'
			})
			.when ('/gonewiththeWind',{
				 templateUrl: 'app/partials/gonewiththeWind.html',
				 controller : 'GonewiththeWindController'
			})
			.when ('/theHost',{
				 templateUrl: 'app/partials/theHost.html',
				 controller : 'TheHostController'
			})
			.when ('/senseandSensibility',{
				 templateUrl: 'app/partials/senseandSensibility.html',
				 controller : 'SenseandSensibilityController'
			})
			.when ('/thePrincessBride',{
				 templateUrl: 'app/partials/thePrincessBride.html',
				 controller : 'ThePrincessBrideController'
			})

			.when ('/fiftyShadesofGrey',{
				 templateUrl: 'app/partials/fiftyShadesofGrey.html',
				 controller : 'FiftyShadesofGreyController'
			})
			.when ('/oryxandCrake',{
				 templateUrl: 'app/partials/oryxandCrake.html',
				 controller : 'OryxandCrakeController'
			})

			.when ('/prey',{
				 templateUrl: 'app/partials/prey.html',
				 controller : 'PreyController'
			})
			.when ('/congo',{
				 templateUrl: 'app/partials/congo.html',
				 controller : 'CongoController'
			})

			.when ('/sphere',{
				 templateUrl: 'app/partials/sphere.html',
				 controller : 'SphereController'
			})
			.when ('/theMartianChronicles',{
				 templateUrl: 'app/partials/theMartianChronicles.html',
				 controller : 'TheMartianChroniclesController'
			})
			.when ('/theAndromedaStrain',{
				 templateUrl: 'app/partials/theAndromedaStrain.html',
				 controller : 'TheAndromedaStrainController'
			})
			.when ('/riptide',{
				 templateUrl: 'app/partials/riptide.html',
				 controller : 'RiptideController'
			})
			.when ('/timeline',{
				 templateUrl: 'app/partials/timeline.html',
				 controller : 'TimelineController'
			})
			.when ('/hyperion',{
				 templateUrl: 'app/partials/hyperion.html',
				 controller : 'HyperionController'
			})
			.when ('/xenocide',{
				 templateUrl: 'app/partials/xenocide.html',
				 controller : 'XenocideController'
			})
			.when ('/presumedInnocent',{
				 templateUrl: 'app/partials/presumedInnocent.html',
				 controller : 'PresumedInnocentController'
			})
			.when ('/theCove',{
				 templateUrl: 'app/partials/theCove.html',
				 controller : 'TheCoveController'
			})
			.when ('/theMaze',{
				 templateUrl: 'app/partials/theMaze.html',
				 controller : 'TheMazeController'
			})
			.when ('/angesetdemons',{
				 templateUrl: 'app/partials/angesetdemons.html',
				 controller : 'AngesetdemonsController'
			})
			.when ('/whiplash',{
				 templateUrl: 'app/partials/whiplash.html',
				 controller : 'WhiplashController'
			})
			.when ('/theTarget',{
				 templateUrl: 'app/partials/theTarget.html',
				 controller : 'TheTargetController'
			})
			.when ('/theBurdenofProof',{
				 templateUrl: 'app/partials/theBurdenofProof.html',
				 controller : 'TheBurdenofProofController'
			})

			.otherwise ({redirectTo: '/home'});

		});
		

      

		
		
		
		